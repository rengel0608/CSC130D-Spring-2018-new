/* 
 * author: Rachel Engel 
 */
public class PlayerRachel extends Player{
	public PlayerRachel() {
    		myName = "Rachel";
	}

	public int ai(GameBoard gb) {
		int move = 0; 
	//boolean firstMove = true;
	
		
	 	int opponentColor;	
	 	int [][]board = gb.getBoard();// column to drop checker into
    if (myColor == GameBoard.RED) {
   
    	
    	opponentColor = GameBoard.BLACK; 
    }
    else {
    	opponentColor = GameBoard.RED;
    	
    }
    // random

    	// if player plays first move in the middle  
    
    	boolean firstMove = false;
    	for (int i= 0; i < board.length; i++) {
    		for (int j = 0; j < board[0].length -1; j++) {
    			if (board[i][j] == myColor && board[i][j + 1] == 0
    			&& gb.isLegalMove(j+1)) {
    				move = j+1;
    				break;
    		
    			}
    	
    			else { 
    				move = -1;
    			}
    				
    }
    if (move == -1) {
    	move = (int)(Math.random() * board[0].length);
    	while (! gb.isLegalMove(move)) {
    	   	move = (int)(Math.random() * board[0].length);
    	}
    	
  
    }
    	
    }
		return move;
	}
}
	
	
	

 

	

