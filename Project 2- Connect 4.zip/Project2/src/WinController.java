/*
 * WinController.java
 * Author:
 * This object's job is to decide
 * if there is a winning configuration 
 * (four in a row) on the board.
 */
public class WinController {
	GameBoard myGameBoard;
	
	public WinController(GameBoard game) {
		myGameBoard = game;
	}

	/* TODO!
	 * Checks horizontal, vertical, and diagonal directions for 
	 * four like checkers in a row. Return true is winner is 
	 * found, otherwise return false.
	 */
	public boolean hasWinner() {
		int[][] board = myGameBoard.getBoard();
		boolean win = false;
	
	for (int i= 0; i < board.length; i++) {
		for (int j = 0; j < board[0].length -3; j++) {
			if (board[i][j] == GameBoard.RED && board[i][j + 3] == GameBoard.RED
			&& board[i][j + 2] == GameBoard.RED && board[i][j + 3] == GameBoard.RED) {
				return true;
			}
			if (board[i][j] == GameBoard.BLACK && board[i][j + 3] == GameBoard.BLACK
					&& board[i][j + 2] == GameBoard.BLACK && board[i][j + 3] == GameBoard.BLACK) {
				return true;
		}
		}
	}
	
			
	// vertical 
	for (int i= 0; i < board.length -3; i++) {
		for (int j = 0; j < board[0].length; j++) {
			if (board[i][j] == GameBoard.RED && board[i + 1][j] == GameBoard.RED
			&& board[i + 2][j] == GameBoard.RED && board[i + 3][j] == GameBoard.RED) {
				return true;
			}
			if (board[i][j] == GameBoard.BLACK && board[i+ 1][j] == GameBoard.BLACK
					&& board[i+ 2][j] == GameBoard.BLACK && board[i + 3][j] == GameBoard.BLACK) {
				return true;	
			
			}
		}
	}
	
	// check diagonal 
	
	for (int i= 0; i < board.length - 3; i++) {
		for (int j = 0; j < board[0].length -3; j++) {
			if (board[i][j] == GameBoard.RED && board[i + 1][j + 1] == GameBoard.RED
				&& board[i + 2][j + 2] == GameBoard.RED && board[i + 3][j+ 3] == GameBoard.RED) {
				return true;
			}
		if (board[i][j] == GameBoard.BLACK && board [i + 1][j + 1] == GameBoard.BLACK
				&& board[i + 2][j + 2] == GameBoard.BLACK && board[i + 3][j+ 3] == GameBoard.BLACK) {
			return true;
		}
			}
		}
	
	
	//check 2nd diagonal 		
			
	for (int i= 0; i < board.length - 3; i++) {
		for (int j = board[0].length -1; j > 2; j--) {
			if (board[i][j] == GameBoard.RED && board[i + 1][j - 1] == GameBoard.RED
				&& board[i + 2][j - 2] == GameBoard.RED && board[i + 3][j- 3] == GameBoard.RED) {
				return true;
			}
		if (board[i][j] == GameBoard.BLACK && board [i + 1][j + 1] == GameBoard.BLACK
				&& board[i + 2][j - 2] == GameBoard.BLACK && board[i + 3][j- 3] == GameBoard.BLACK) {		
			return true;
		}
		}
	}
	return false;
	}
}

			
